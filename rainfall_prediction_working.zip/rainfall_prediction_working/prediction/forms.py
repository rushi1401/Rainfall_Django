from django import forms

class RainfallPredictionForm(forms.Form):
    temperature = forms.FloatField(
        label='Temperature (°C)',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter temperature (e.g., 25.5)',
            'step': '0.1',
            'min': '-50',
            'max': '60'
        }),
        help_text='Temperature in Celsius'
    )
    
    humidity = forms.FloatField(
        label='Humidity (%)',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter humidity (e.g., 80.0)',
            'step': '0.1',
            'min': '0',
            'max': '100'
        }),
        help_text='Humidity percentage (0-100)'
    )
    
    windspeed = forms.FloatField(
        label='Wind Speed (km/h)',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter wind speed (e.g., 15.0)',
            'step': '0.1',
            'min': '0',
            'max': '200'
        }),
        help_text='Wind speed in km/h'
    )