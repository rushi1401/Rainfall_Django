import os
import joblib
import pandas as pd
from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
from .forms import RainfallPredictionForm

def load_model():
    """Load the trained ML model"""
    try:
        model_path = settings.ML_MODEL_PATH
        if os.path.exists(model_path):
            return joblib.load(model_path)
        else:
            raise FileNotFoundError(f"Model file not found at {model_path}")
    except Exception as e:
        print(f"Error loading model: {e}")
        return None

def predict_rainfall(request):
    """Main prediction view with form"""
    if request.method == 'POST':
        form = RainfallPredictionForm(request.POST)
        if form.is_valid():
            # Get form data
            temperature = form.cleaned_data['temperature']
            humidity = form.cleaned_data['humidity']
            windspeed = form.cleaned_data['windspeed']
            
            # Load model and make prediction
            model = load_model()
            if model is None:
                messages.error(request, 'Error: Could not load the prediction model.')
                return render(request, 'prediction/predict.html', {'form': form})
            
            try:
                # Prepare input data (same order as training: temperature, humidity, windspeed)
                input_data = [[temperature, humidity, windspeed]]
                
                # Make prediction
                prediction = model.predict(input_data)[0]
                prediction_proba = model.predict_proba(input_data)[0]
                
                # Store results in session
                request.session['prediction_data'] = {
                    'temperature': temperature,
                    'humidity': humidity,
                    'windspeed': windspeed,
                    'prediction': int(prediction),
                    'probability_no_rain': round(prediction_proba[0] * 100, 2),
                    'probability_rain': round(prediction_proba[1] * 100, 2),
                }
                
                return redirect('prediction:result')
                
            except Exception as e:
                messages.error(request, f'Error making prediction: {str(e)}')
                return render(request, 'prediction/predict.html', {'form': form})
    else:
        form = RainfallPredictionForm()
    
    return render(request, 'prediction/predict.html', {'form': form})

def prediction_result(request):
    """Display prediction results"""
    prediction_data = request.session.get('prediction_data')
    
    if not prediction_data:
        messages.warning(request, 'No prediction data found. Please make a prediction first.')
        return redirect('prediction:predict')
    
    # Clear session data
    del request.session['prediction_data']
    
    return render(request, 'prediction/result.html', {'data': prediction_data})