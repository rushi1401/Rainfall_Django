# from django.urls import path
# from . import views

# app_name = 'prediction'

# urlpatterns = [
#     path('', views.predict_rainfall, name='predict'),
#     path('result/', views.prediction_result, name='result'),
# ]
from django.urls import path
from . import views

app_name = 'prediction'

urlpatterns = [
    path('', views.predict_rainfall, name='predict'),
    path('result/', views.prediction_result, name='result'),
]